import requests, json

GEMINI_KEY = "AIzaSyD2nw-as9AwBqJh_RB0C2LWG8KwzqG5k3c"
url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
headers = {"x-goog-api-key": GEMINI_KEY, "Content-Type": "application/json"}

# YouTube URL을 직접 Gemini에 전달
body = {
    "contents": [{
        "parts": [
            {"fileData": {"fileUri": "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "mimeType": "video/*"}},
            {"text": "이 영상의 내용을 한국어로 요약해주세요. 핵심 포인트를 정리해주세요."}
        ]
    }]
}

print("Gemini에 YouTube URL 직접 전송...")
resp = requests.post(url, headers=headers, json=body, timeout=120)
print(f"Status: {resp.status_code}")

if resp.status_code == 200:
    data = resp.json()
    for c in data.get("candidates", []):
        for p in c.get("content", {}).get("parts", []):
            if "text" in p:
                print(f"\n=== Gemini 분석 결과 ===")
                print(p["text"][:500])
    print("\n✅ SUCCESS - YouTube URL 직접 분석 가능!")
else:
    print(f"Error: {resp.text[:400]}")
