"""
🏢 YouTube Knowledge Office — 자동 수집 사무실 서버
CEO + 팀원들이 유튜브에서 카테고리별 지식을 자동 수집하는 가상 사무실
http://127.0.0.1:8000/
"""

import os
import sys
import json
import time
import asyncio
import random
import re
import datetime
import threading
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.responses import StreamingResponse
import uvicorn

# ── 환경 설정 ──
BASE_DIR = Path(__file__).parent
# 지식 저장소 경로 (사용자 요청에 따라 H:\obsidean으로 변경)
KNOWLEDGE_DIR = Path(r"H:\obsidean")
LOG_DIR = BASE_DIR / "logs"
STATIC_DIR = BASE_DIR / "static"

KNOWLEDGE_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)
STATIC_DIR.mkdir(exist_ok=True)
(STATIC_DIR / "images").mkdir(exist_ok=True)

# .env에서 Gemini API 키 로드
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
env_path = Path(r"h:\Users\ppitu\AppData\Local\Programs\Microsoft VS Code\chart-app\.env")
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("GEMINI_API_KEY="):
            GEMINI_API_KEY = line.split("=", 1)[1].strip()

# Ollama 설정 (로컬 모델용)
OLLAMA_URL = "http://127.0.0.1:11434/api/generate"
DEFAULT_LOCAL_MODEL = "gemma4:e4b"  # 정민재용 (8B 로컬 — 빠름)
SECOND_LOCAL_MODEL = "gemma4:e4b"  # 조아라용 (동일 모델)
GEMINI_CLOUD_MODEL = "gemini-2.5-flash"  # 클라우드 폴백 (한도 있음)

# Gemini REST API 설정 (로컬 실패 시 폴백용)
GEMINI_REST_MODEL = "gemini-2.5-flash"

# 텔레그램 설정
TELEGRAM_BOT_TOKEN = "8591214231:AAFYS_JElbLkK-M8Cy3fOBuASUNrUH8mZhU"
TELEGRAM_CHAT_IDS = ["1839385089", "-5246268529"]  # 개인 + 그룹 채팅방

# ── 수집 설정 ──
CHECK_INTERVAL = 30    # 30초마다 확인 (더 빈번하게)
MAX_RESULTS = 50       # 각 채널/검색당 가져올 영상 개수 대폭 확대

# ── Google Drive 연동 ──
CREDENTIALS_FILE = BASE_DIR / "credentials.json"
USERS_FILE = BASE_DIR / "users.json"
SERVICE_ACCOUNT_EMAIL = "ppitu09@youypor.iam.gserviceaccount.com"
SESSIONS_FILE = BASE_DIR / "sessions.json"

def load_sessions():
    if SESSIONS_FILE.exists():
        try: return json.loads(SESSIONS_FILE.read_text(encoding="utf-8"))
        except: return {}
    return {}

def save_sessions(sessions: dict):
    try: SESSIONS_FILE.write_text(json.dumps(sessions, ensure_ascii=False, indent=2), encoding="utf-8")
    except: pass

user_sessions = load_sessions()
daily_goal_notified = False
_last_daily_reset = datetime.datetime.now().strftime("%Y-%m-%d")
_telegram_recent_titles = []  # 텔레그램 배치 전송용 버퍼

def load_users():
    if USERS_FILE.exists():
        return json.loads(USERS_FILE.read_text(encoding="utf-8"))
    return {}

def save_users(users: dict):
    USERS_FILE.write_text(json.dumps(users, ensure_ascii=False, indent=2), encoding="utf-8")

def get_drive_service():
    """Google Drive API 서비스 생성"""
    try:
        from google.oauth2 import service_account
        from googleapiclient.discovery import build
        creds = service_account.Credentials.from_service_account_file(
            str(CREDENTIALS_FILE),
            scopes=['https://www.googleapis.com/auth/drive']
        )
        return build('drive', 'v3', credentials=creds)
    except Exception as e:
        print(f"Drive 서비스 생성 실패: {e}")
        return None

def upload_to_drive(folder_id: str, filename: str, content: str):
    """Google Drive 폴더에 .md 파일 업로드 (사용자 공유 폴더에 저장)"""
    try:
        from googleapiclient.http import MediaInMemoryUpload
        service = get_drive_service()
        if not service:
            return False
        
        # print(f"DEBUG: Drive 업로드 시도 - 폴더: {folder_id}, 파일: {filename}")
        
        media = MediaInMemoryUpload(
            content.encode('utf-8'), 
            mimetype='text/plain',
            resumable=True
        )
        file_metadata = {
            'name': filename,
            'parents': [folder_id],
            'mimeType': 'text/plain'
        }
        
        # supportsAllDrives와 supportsTeamDrives를 모두 True로 설정
        result = service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id',
            supportsAllDrives=True,
            supportsTeamDrives=True
        ).execute()
        
        if result.get('id'):
            return True
        return False
    except Exception as e:
        print(f"Drive 업로드 실패 (폴더ID: {folder_id}): {e}")
        return False

def extract_folder_id(drive_url: str) -> str:
    """Google Drive 폴더 URL에서 폴더 ID 추출"""
    # https://drive.google.com/drive/folders/FOLDER_ID
    m = re.search(r'/folders/([a-zA-Z0-9_-]+)', drive_url)
    if m:
        return m.group(1)
    # 그냥 ID만 입력한 경우
    if re.match(r'^[a-zA-Z0-9_-]{20,}$', drive_url.strip()):
        return drive_url.strip()
    return ""

# ── 카테고리 정의 (해외+국내 키워드 대폭 확장) ──
CATEGORIES = {
    "science": {
        "name": "🔬 과학/우주",
        "keywords": ["science documentary 2025", "space exploration NASA", "quantum physics explained",
                     "black hole discovery", "James Webb telescope", "우주 다큐멘터리",
                     "nuclear fusion breakthrough", "CERN particle", "exoplanet habitable",
                     "생물학 최신 발견", "유전자 편집 CRISPR", "화성 탐사", "neuroscience brain"],
        "channels": ["https://www.youtube.com/@Kurzgesagt/videos", "https://www.youtube.com/@Veritasium/videos"]
    },
    "tech": {
        "name": "💻 기술/AI",
        "keywords": ["AI news 2025", "GPT-5 release", "artificial intelligence documentary",
                     "robotics future", "인공지능 최신 뉴스", "Apple WWDC Google IO",
                     "autonomous driving Tesla", "quantum computing", "AI agent coding",
                     "open source LLM", "semiconductor chip war", "반도체 전쟁",
                     "cybersecurity hacking 2025", "코딩 독학 프로젝트"],
        "channels": ["https://www.youtube.com/@Fireship/videos", "https://www.youtube.com/@TwoMinutePapers/videos"]
    },
    "business": {
        "name": "💼 비즈니스/경제",
        "keywords": ["stock market analysis 2025", "global economy recession", "Warren Buffett investing",
                     "경제 위기 분석", "cryptocurrency bitcoin 2025", "startup unicorn",
                     "미국 금리", "일본 경제 엔화", "중국 경제 위기", "부동산 전망",
                     "ETF 투자 전략", "passive income ideas", "한국 스타트업 IPO"],
        "channels": ["https://www.youtube.com/@3proTV/videos", "https://www.youtube.com/@syukaworld/videos"]
    },
    "health": {
        "name": "🏥 건강/의학",
        "keywords": ["longevity science anti aging", "nutrition science diet", "exercise science",
                     "mental health documentary", "gut microbiome research", "sleep optimization",
                     "cancer research breakthrough 2025", "Harvard health Stanford medicine",
                     "건강 상식 의학", "운동 과학 다이어트"],
        "channels": ["https://www.youtube.com/@닥터프렌즈/videos"]
    },
    "philosophy": {
        "name": "📚 철학/인문/역사",
        "keywords": ["history documentary ancient civilization", "World War documentary",
                     "Roman Empire rise fall", "역사 다큐 조선시대", "Egyptian pyramids mystery",
                     "Greek philosophy Socrates Plato", "중세 유럽 르네상스",
                     "cold war documentary", "한국전쟁 6.25", "삼국지 역사",
                     "Stoicism Marcus Aurelius", "Korean history Joseon dynasty"],
        "channels": ["https://www.youtube.com/@CrashCourse/videos"]
    },
    "psychology": {
        "name": "🧠 심리학/행동과학",
        "keywords": ["psychology documentary experiment", "emotional intelligence",
                     "dark psychology manipulation", "body language analysis",
                     "심리학 강의 뇌과학", "consciousness explained", "addiction science",
                     "narcissism toxic relationship", "인지과학 행동경제학"],
        "channels": ["https://www.youtube.com/@Psych2Go/videos"]
    },
    "design": {
        "name": "🎨 디자인/크리에이티브",
        "keywords": ["UI UX design trends 2025", "web design inspiration portfolio",
                     "Figma tutorial advanced", "motion graphics After Effects",
                     "3D modeling Blender tutorial", "디자인 트렌드 로고", "branding strategy"],
        "channels": ["https://www.youtube.com/@DesignCourse/videos"]
    },
    "selfdev": {
        "name": "📈 자기계발/생산성",
        "keywords": ["productivity system deep work", "atomic habits James Clear",
                     "morning routine millionaire", "Obsidian note taking second brain",
                     "time management Pomodoro", "자기계발 독서 습관", "goal setting OKR"],
        "channels": ["https://www.youtube.com/@ThomasFrankExplains/videos"]
    },
    "global": {
        "name": "🌍 국제정세/지정학",
        "keywords": ["geopolitics 2025 world order", "US China trade war",
                     "NATO Russia Ukraine war", "Middle East Israel Iran",
                     "Taiwan strait crisis", "미중 관계 패권 경쟁", "BRICS expansion",
                     "Africa rising economy", "India superpower 2030", "한일 관계 외교",
                     "immigration crisis Europe", "North Korea nuclear missile"],
        "channels": ["https://www.youtube.com/@VisualPolitikEN/videos"]
    },
    "nature": {
        "name": "🌿 자연/환경",
        "keywords": ["nature documentary 4K deep ocean", "climate change effects 2025",
                     "endangered species conservation", "Amazon rainforest deforestation",
                     "volcanic eruption earthquake tsunami", "자연 다큐멘터리 해양 생물",
                     "renewable energy solar wind nuclear", "Arctic melting ice"],
        "channels": ["https://www.youtube.com/@NatGeo/videos", "https://www.youtube.com/@BBCEarth/videos"]
    },
}

# ── 팀 구조 ──
TEAM_STRUCTURE = {
    "ceo": {
        "id": "ceo_01",
        "name": "김지원 CEO",
        "role": "최고경영자",
        "team": "경영진",
        "avatar_idx": 4,  # glasses character
        "color": "#FFD700",
        "desk": {"x": 75, "y": 12},
        "tasks": ["전체 업무 감독", "수집 전략 수립", "품질 검토"],
    },
    "research_lead": {
        "id": "research_01",
        "name": "조아라 팀장",
        "role": "리서치팀장",
        "team": "리서치팀",
        "avatar_idx": 1,  # brown hair female
        "color": "#7C83FD",
        "desk": {"x": 18, "y": 35},
        "tasks": ["채널 탐색", "영상 분석", "키워드 추출"],
    },
    "researcher_1": {
        "id": "research_02",
        "name": "이준호 연구원",
        "role": "시니어 연구원",
        "team": "리서치팀",
        "avatar_idx": 0,  # white shirt male
        "color": "#A0D2DB",
        "desk": {"x": 18, "y": 48},
        "tasks": ["과학/우주 카테고리 담당", "자막 수집"],
    },
    "researcher_2": {
        "id": "research_03",
        "name": "최수아 연구원",
        "role": "주니어 연구원",
        "team": "리서치팀",
        "avatar_idx": 3,  # dark hair female
        "color": "#E8A0BF",
        "desk": {"x": 18, "y": 60},
        "tasks": ["기술/AI 카테고리 담당", "트렌드 분석"],
    },
    "data_lead": {
        "id": "data_01",
        "name": "정민재 팀장",
        "role": "데이터팀장",
        "team": "데이터팀",
        "avatar_idx": 2,  # blue shirt male
        "color": "#82C3EC",
        "desk": {"x": 50, "y": 35},
        "tasks": ["데이터 정제", "카테고리 분류", "저장 관리"],
    },
    "data_engineer": {
        "id": "data_02",
        "name": "한소희 엔지니어",
        "role": "데이터 엔지니어",
        "team": "데이터팀",
        "avatar_idx": 5,  # bun hair female
        "color": "#B0E0E6",
        "desk": {"x": 50, "y": 48},
        "tasks": ["Gemini AI 처리", "마크다운 변환", "중복 검사"],
    },
    "qa_lead": {
        "id": "qa_01",
        "name": "윤하은 팀장",
        "role": "품질관리팀장",
        "team": "품질관리팀",
        "avatar_idx": 9,  # pink shirt female
        "color": "#FFB6C1",
        "desk": {"x": 75, "y": 35},
        "tasks": ["품질 검토", "오류 수정", "리포트 작성"],
    },
    "qa_member": {
        "id": "qa_02",
        "name": "강도윤 QA",
        "role": "QA 엔지니어",
        "team": "품질관리팀",
        "avatar_idx": 7,  # dark hair male casual
        "color": "#98D8C8",
        "desk": {"x": 75, "y": 48},
        "tasks": ["로그 모니터링", "통계 업데이트", "이슈 추적"],
    },
    "intern": {
        "id": "intern_01",
        "name": "송예린 인턴",
        "role": "인턴",
        "team": "리서치팀",
        "avatar_idx": 8,  # yellow top female
        "color": "#F0E68C",
        "desk": {"x": 50, "y": 60},
        "tasks": ["비즈니스/경제 카테고리 보조", "파일 정리"],
    },
}

# ── 전역 상태 ──
activity_log = []
collection_stats = {
    "total_collected": 0,
    "by_category": {cat: 0 for cat in CATEGORIES},
    "today_collected": 0,
    "last_collection": None,
    "is_running": False,
}
sse_clients = []
_main_loop = None  # uvicorn 이벤트 루프 저장용
worker_states = {}
current_tasks = {}  # 각 팀원의 현재 작업
user_sessions = {}  # {이메일: {"connected_at": timestamp, "last_seen": timestamp, "personal_count": 0}}

# ── 로깅 ──
def add_log(member_id: str, action: str, detail: str = "", category: str = ""):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    member = None
    for k, v in TEAM_STRUCTURE.items():
        if v["id"] == member_id:
            member = v
            break
    
    entry = {
        "timestamp": timestamp,
        "member_id": member_id,
        "member_name": member["name"] if member else "시스템",
        "team": member["team"] if member else "시스템",
        "action": action,
        "detail": detail,
        "category": category,
    }
    activity_log.append(entry)
    
    # 터미널 출력 (디버깅용)
    print(f"[{timestamp}] [{member_id}] {action}: {detail}")
    
    # 파일 로그 저장
    log_file = LOG_DIR / f"activity_{datetime.datetime.now().strftime('%Y%m%d')}.log"
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    
    # SSE 브로드캐스트
    broadcast_event("log", entry)
    
    # 최대 500개 로그 유지
    if len(activity_log) > 500:
        activity_log.pop(0)

def broadcast_event(event_type: str, data: dict):
    """모든 연결된 SSE 클라이언트에게 이벤트 전송 (스레드 세이프)"""
    msg = json.dumps({"type": event_type, "data": data}, ensure_ascii=False)
    global _main_loop
    if _main_loop and _main_loop.is_running():
        for q in list(sse_clients):
            try:
                _main_loop.call_soon_threadsafe(q.put_nowait, msg)
            except:
                pass
    else:
        for q in list(sse_clients):
            try:
                q.put_nowait(msg)
            except:
                pass

# ── YouTube 수집 엔진 ──
class YouTubeCollector:
    def __init__(self):
        self.running = False
        self._stop_event = threading.Event()
        self._manual_stop = False  # 사용자 수동 정지 플래그
        self.processed_file = BASE_DIR / "processed_videos.json"
        self.processed_ids = self._load_processed_ids()
        self.failed_ids = {}  # {video_id: fail_count} — 3번까지 재시도
        self.current_model = DEFAULT_LOCAL_MODEL # 기본값: Gemma 4
        self.lock = threading.Lock()
        self.last_heartbeat = time.time()  # 워커 생존 확인용
    
    def _load_processed_ids(self):
        if self.processed_file.exists():
            try:
                return set(json.loads(self.processed_file.read_text(encoding='utf-8')))
            except:
                return set()
        return set()

    def _save_processed_ids(self):
        self.processed_file.write_text(json.dumps(list(self.processed_ids), ensure_ascii=False), encoding='utf-8')

    def stop(self):
        self._stop_event.set()
        self.running = False
    
    def collect_channel_videos(self, channel_url: str, category: str, max_videos: int = 100):
        """채널에서 영상 목록을 가져옵니다 (탐색 범위를 100개로 확대)"""
        import yt_dlp
        
        # Try both /videos and base URL
        urls_to_try = []
        if channel_url.startswith("https://www.youtube.com/@") and not channel_url.endswith("/videos"):
            urls_to_try.append(f"{channel_url.rstrip('/')}/videos")
        urls_to_try.append(channel_url)
            
        for target_url in urls_to_try:
            ydl_opts = {
                'extract_flat': True,
                'quiet': True,
                'playlistend': max_videos,
                'ignoreerrors': True,
                'retries': 3,
                'fragment_retries': 5,
            }
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(target_url, download=False)
                    # 채널 탐색 실패 시 키워드 검색으로 전환
                    if not info or 'entries' not in info or not info['entries']:
                        if "@" in target_url:
                            channel_name = target_url.split("@")[-1].split("/")[0]
                            add_log("research_01", "🔄 채널 직접 탐색 실패, 검색으로 전환", channel_name, category)
                            search_url = f"ytsearch{max_videos}:{channel_name}"
                            info = ydl.extract_info(search_url, download=False)

                    if info and 'entries' in info:
                        videos = []
                        for entry in info['entries']:
                            if entry:
                                videos.append({
                                    'id': entry.get('id'),
                                    'title': entry.get('title')
                                })
                        if videos:
                            add_log("research_02", f"{len(videos)}개 영상 발견", f"{target_url}", category)
                            return videos
            except Exception as e:
                continue # Try next URL
                
        add_log("research_02", "채널 탐색 실패", channel_url, category)
        return []
    
    def get_transcript(self, video_id: str, category: str, title: str = ""):
        """자막을 가져옵니다: 자막API → 메타데이터 → 제목 기반 AI 분석"""
        add_log("research_03", "자막 수집 중", f"Video ID: {video_id}", category)
        
        # ── 1단계: 자막 API 시도 (빠르고 정확) ──
        subtitle_text = self._try_subtitle_apis(video_id, category)
        if subtitle_text:
            return subtitle_text
        
        # ── 2단계: 메타데이터 모드 (제목+설명+URL → Gemma4가 직접 분석) ──
        add_log("research_03", "🔗 메타데이터 모드 전환", video_id, category)
        meta_text = self._try_metadata(video_id, category)
        if meta_text:
            return meta_text
        
        # ── 3단계: 제목 기반 AI 분석 (조아라: Gemma4) ──
        if title:
            add_log("research_03", "🧠 제목 기반 지식 생성", title[:40], category)
            gemini_text = self._try_gemini_url_analysis(video_id, category, title)
            if gemini_text:
                return gemini_text
        
        # ── 최종 폴백: URL+제목 → Gemma4 직접 분석 (절대 멈추지 않음) ──
        if title:
            add_log("research_03", "🤖 Gemma4 직접 분석 모드", title[:40], category)
            yt_url = f"https://www.youtube.com/watch?v={video_id}"
            fallback_prompt = f"""당신은 YouTube 영상 분석 전문가입니다.

아래 YouTube 영상의 제목과 URL을 바탕으로, 이 영상이 다루고 있을 핵심 내용을 상세하게 분석하여 지식 문서를 작성하세요.

영상 제목: {title}
영상 URL: {yt_url}

## 작성 규칙:
1. 제목에서 유추되는 핵심 주제를 깊이 있게 분석
2. 관련 배경 지식과 맥락을 포함
3. 핵심 키워드를 [[키워드]] 형태로 링크
4. 마크다운 형식으로 구조화

## 필수 구조:
- 📌 핵심 요약 (3-5줄)
- 📖 주요 내용 (상세 분석)
- 🔑 핵심 키워드
- 🔗 관련 주제

**[필수] 반드시 한국어로만 작성하세요.**
"""
            try:
                import requests
                payload = {"model": DEFAULT_LOCAL_MODEL, "prompt": fallback_prompt, "stream": False}
                resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
                resp.raise_for_status()
                text = resp.json().get("response", "")
                if text and len(text) > 100:
                    add_log("research_03", "🏆 Gemma4 직접 분석 완료!", title[:40], category)
                    return text
            except Exception as e:
                add_log("research_03", f"⚠️ Gemma4 직접 분석 실패", str(e)[:40], category)
        
        add_log("research_03", "자막 수집 실패", video_id, category)
        return None
    
    def _try_gemini_url_analysis(self, video_id: str, category: str, title: str = ""):
        """제목 기반 AI 분석 (조아라 팀장 — Gemma4 사용)"""
        import requests
        
        yt_url = f"https://www.youtube.com/watch?v={video_id}"
        prompt = f"""YouTube 영상 제목: 「{title}」
영상 URL: {yt_url}
카테고리: {category}

이 YouTube 영상의 **제목**을 바탕으로, 이 영상이 다루고 있을 핵심 내용을 한국어로 정리해주세요.
제목에서 유추할 수 있는 주제, 배경 지식, 관련 사실들을 정확하게 작성하세요.

**중요**: 제목과 관련 없는 내용은 절대 쓰지 마세요. 제목에 나온 주제만 다루세요.

마크다운 형식으로 작성:
- 📌 핵심 요약 (3-5줄)
- 📖 주요 내용 (제목 기반 지식)
- 🔑 핵심 키워드

**[필수] 반드시 한국어로만 작성하세요. 중국어, 영어 사용 금지.**
"""
        for attempt in range(3):
            try:
                add_log("research_01", f"🔍 조아라[Gemma4]: 제목 분석 시작", title[:40], category)
                payload = {"model": SECOND_LOCAL_MODEL, "prompt": prompt, "stream": False}
                resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
                resp.raise_for_status()
                text = resp.json().get("response", "")
                if text and len(text) > 50:
                    add_log("research_01", "🏆 조아라[Gemma4]: 분석 완료!", f"{title[:30]} ({len(text)}자)", category)
                    return f"[제목 기반 AI 분석]\n영상: {yt_url}\n제목: {title}\n\n{text}"
                break
            except Exception as e:
                if attempt < 2:
                    add_log("research_01", f"⏳ 조아라: Ollama 대기 ({attempt+1}/3)", "", category)
                    time.sleep(5)
                    continue
                add_log("research_01", f"⚠️ 조아라[Gemma4]: 실패", str(e)[:40], category)
        
        return None
    
    def _try_metadata(self, video_id: str, category: str):
        """yt-dlp로 메타데이터(제목, 설명, 태그)만 가져와서 Gemma4에게 URL 분석 요청"""
        try:
            import subprocess
            cmd = [sys.executable, "-m", "yt_dlp",
                   "--skip-download", "--no-playlist",
                   "--print", "%(title)s\n---DESC---\n%(description)s\n---TAGS---\n%(tags)s",
                   f"https://www.youtube.com/watch?v={video_id}"]
            result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(BASE_DIR), timeout=30)
            
            if result.returncode == 0 and result.stdout.strip():
                output = result.stdout.strip()
                # 제목과 설명 파싱
                parts = output.split('---DESC---')
                meta_title = parts[0].strip() if len(parts) > 0 else ""
                desc_rest = parts[1] if len(parts) > 1 else ""
                desc_parts = desc_rest.split('---TAGS---')
                description = desc_parts[0].strip()[:3000] if len(desc_parts) > 0 else ""
                tags = desc_parts[1].strip()[:500] if len(desc_parts) > 1 else ""
                
                # 메타데이터를 transcript처럼 조합
                meta_text = f"[YouTube 영상 메타데이터 분석]\n"
                meta_text += f"영상 URL: https://www.youtube.com/watch?v={video_id}\n"
                meta_text += f"제목: {meta_title}\n"
                if description:
                    meta_text += f"설명:\n{description}\n"
                if tags:
                    meta_text += f"태그: {tags}\n"
                meta_text += "\n위 정보를 바탕으로 이 영상의 핵심 내용을 분석하고 지식 문서를 작성해주세요."
                
                add_log("research_03", "🔗 메타데이터 수집 성공", f"제목: {meta_title[:40]}", category)
                return meta_text
        except Exception as e:
            add_log("research_03", "메타데이터 수집 실패", str(e)[:50], category)
        return None
    
    def _try_subtitle_apis(self, video_id: str, category: str):
        """자막 API들을 순차 시도 (실패하면 None)"""
        # 1) YouTubeTranscriptApi
        try:
            from youtube_transcript_api import YouTubeTranscriptApi
            api = YouTubeTranscriptApi()
            transcript_list = api.fetch(video_id, languages=['ko', 'en'])
            text = " ".join([t.text if hasattr(t, 'text') else t['text'] for t in transcript_list])
            add_log("research_03", "자막 수집 성공", f"{len(text)}자", category)
            return text
        except:
            pass
        
        # 2) yt-dlp 자막 다운로드
        try:
            import subprocess
            add_log("research_03", "자막 수집 재시도 (yt-dlp)", video_id, category)
            
            cmd = [sys.executable, "-m", "yt_dlp", 
                   "--write-subs", "--write-auto-subs",
                   "--sub-lang", "ko,en.*",
                   "--skip-download", 
                   "--convert-subs", "vtt",
                   "-o", f"{video_id}.%(ext)s",
                   f"https://www.youtube.com/watch?v={video_id}"]
            
            subprocess.run(cmd, capture_output=True, text=True, cwd=str(BASE_DIR), timeout=60)
            
            vtt_files = list(BASE_DIR.glob(f"{video_id}*.vtt"))
            if vtt_files:
                target_file = None
                for f in vtt_files:
                    if '.ko.' in f.name:
                        target_file = f
                        break
                if not target_file:
                    target_file = vtt_files[0]
                
                text = target_file.read_text(encoding='utf-8')
                clean_lines = []
                for line in text.split('\n'):
                    line = line.strip()
                    if not line or '-->' in line or line.startswith(('WEBVTT', 'Language:', 'Kind:')):
                        continue
                    cleaned = re.sub(r'<[^>]+>', '', line)
                    if cleaned and (not clean_lines or clean_lines[-1] != cleaned):
                        clean_lines.append(cleaned)
                
                for f in vtt_files:
                    try: f.unlink()
                    except: pass
                
                result = " ".join(clean_lines)
                if len(result) > 50:  # 의미있는 자막인지 확인
                    add_log("research_03", "자막 수집 성공 (yt-dlp)", f"{len(result)}자", category)
                    return result
        except:
            pass
        
        return None
    
    def _try_whisper(self, video_id: str, category: str):
        """오디오 다운로드 + Whisper 로컬 음성인식 (타임아웃 180초)"""
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            add_log("intern_01", "⚠️ faster-whisper 미설치", "pip install faster-whisper 필요", category)
            return None
        
        try:
            import subprocess
            audio_path = BASE_DIR / f"audio_{video_id}"
            
            cmd = [sys.executable, "-m", "yt_dlp", 
                   "-f", "ba[ext=m4a]/ba",
                   "--no-playlist",
                   "--extractor-args", "youtube:player_client=android_vr",
                   "-o", f"{audio_path}.%(ext)s",
                   f"https://www.youtube.com/watch?v={video_id}"]
            
            result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(BASE_DIR), timeout=90)
            
            audio_files = list(BASE_DIR.glob(f"audio_{video_id}.*"))
            if not audio_files:
                add_log("intern_01", "⚠️ 오디오 다운로드 실패", video_id, category)
                return None
            
            actual_audio = audio_files[0]
            file_size_mb = actual_audio.stat().st_size / (1024 * 1024)
            
            if file_size_mb > 30:
                add_log("intern_01", "⚠️ 오디오 너무 큼, 스킵", f"{file_size_mb:.0f}MB", category)
                actual_audio.unlink()
                return None
            
            add_log("intern_01", f"🎵 오디오 ({file_size_mb:.1f}MB), Whisper 분석 시작 (3분 제한)", video_id, category)
            self.last_heartbeat = time.time()
            
            # 타임아웃 스레드로 Whisper 실행 (멈춤 방지)
            whisper_result = [None]
            def run_whisper():
                try:
                    model = WhisperModel("tiny", device="cpu", compute_type="int8")
                    segments, info = model.transcribe(str(actual_audio), beam_size=3)
                    texts = [seg.text for seg in segments]
                    whisper_result[0] = " ".join(texts)
                except Exception as e:
                    whisper_result[0] = None
            
            t = threading.Thread(target=run_whisper, daemon=True)
            t.start()
            t.join(timeout=180)  # 최대 3분
            
            # 오디오 즉시 정리
            try: actual_audio.unlink()
            except: pass
            
            if t.is_alive():
                add_log("intern_01", "⏰ Whisper 타임아웃 (3분 초과), 건너뜀", video_id, category)
                return None
            
            transcript = whisper_result[0]
            if transcript and len(transcript) > 50:
                add_log("intern_01", "🎧 Whisper AI 음성인식 성공!", f"{len(transcript)}자", category)
                return transcript
            else:
                add_log("intern_01", "⚠️ 음성 인식 결과 너무 짧음", "", category)
                return None
                
        except Exception as e:
            add_log("intern_01", "음성 인식 실패", str(e)[:80], category)
            for f in BASE_DIR.glob(f"audio_{video_id}.*"):
                try: f.unlink()
                except: pass
            return None
    
    def process_with_gemini(self, title: str, transcript: str, category: str, video_id: str):
        """선택된 모델(Gemma/Gemini)로 지식 문서 생성"""
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        source_url = f"https://www.youtube.com/watch?v={video_id}"
        
        # [Andrej Karpathy Principles] 기반 지식 추출 프롬프트
        prompt = f"""
당신은 안드레 카르파시(Andrej Karpathy)의 엔지니어링 원칙을 준수하는 지식 추출 전문가입니다.

## 원칙 준수 사항:
1. **Simplicity First**: 불필요한 서술이나 복잡한 추상화를 제거하고, 영상의 핵심 사실(Facts)과 로직(Logic)만 간결하게 추출하세요.
2. **Surgical Extraction**: 영상에 실제로 언급된 내용만 정교하게 추출하세요. 추측이나 speculative한 내용은 배제합니다.
3. **Goal-Driven**: Obsidian에서 즉시 활용 가능한 '지식 원자' 단위로 정보를 파편화하지 않고 구조화하세요.

## 문서 구조 요구사항:
- YAML Frontmatter (tags, date, source_url)
- 핵심 요약 (Surgical Summary)
- 주요 지식 포인트 (Bullet points)
- 백링크 처리: 중요한 개념은 반드시 [[키워드]] 형태로 링크하세요.

영상 제목: {title}
출처 URL: {source_url}

텍스트 내용(Raw Data):
{transcript[:3000]}

**[필수] 반드시 한국어로만 작성하세요. 중국어, 영어 사용 금지. 모든 내용을 한국어로 출력하세요.**
**결과물은 마크다운 형식으로만, 인삿말 없이 원칙에 따라 정교하게 작성하세요.**
"""

        # ═══ Gemma4 로컬 AI로 분석 (재시도 3회) ═══
        import requests
        for attempt in range(3):
            try:
                add_log("data_02", f"🏠 정민재: Gemma4 분석 시작", title[:40], category)
                payload = {"model": DEFAULT_LOCAL_MODEL, "prompt": prompt, "stream": False}
                resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
                resp.raise_for_status()
                text = resp.json().get("response", "")
                if text and len(text) > 100:
                    add_log("data_02", "🏆 정민재: Gemma4 분석 완료!", title[:40], category)
                    return text
                else:
                    add_log("data_02", "⚠️ 결과 너무 짧음, 원본 저장", "", category)
                    break
            except Exception as e:
                err = str(e)[:40]
                if attempt < 2:
                    add_log("data_02", f"⏳ 재시도 중 ({attempt+1}/3)", err, category)
                    time.sleep(5)
                    continue
                add_log("data_02", f"⚠️ Gemma4 실패: {err}", title[:30], category)
        
        # 실패 시 원본 텍스트라도 저장 (수집은 멈추지 않음)
        return f"# {title}\n\n## 📌 Brief Summary\n(AI 분석 실패 — 원본 저장)\n\n## 📖 Core Content\n{transcript[:3000]}...\n\n--- \n*Auto-collected: {today}*"
    
    def save_document(self, title: str, content: str, category: str):
        """날짜별/카테고리별 폴더에 문서 저장"""
        today_str = datetime.datetime.now().strftime("%Y-%m-%d")
        # 구조: H:\obsidean\2026-05-04\tech\title.md
        dest_dir = KNOWLEDGE_DIR / today_str / category
        dest_dir.mkdir(parents=True, exist_ok=True)
        
        safe_title = re.sub(r'[<>:"/\\|?*]', '', title)[:80]
        file_path = dest_dir / f"{safe_title}.md"
        
        # 중복 검사 (같은 날짜 폴더 내에서만)
        if file_path.exists():
            add_log("data_01", "중복 문서 스킵", safe_title, category)
            return False
        
        file_path.write_text(content, encoding='utf-8')
        
        add_log("data_01", "📁 문서 저장 완료", f"{today_str}/{category}/{safe_title}.md", category)

        # ── 실시간 통계 업데이트 (성능 최적화: 매번 디스크를 스캔하지 않고 증분) ──
        with self.lock:
            collection_stats["total_collected"] += 1
            collection_stats["today_collected"] = collection_stats.get("today_collected", 0) + 1
            
            if "by_category" not in collection_stats:
                collection_stats["by_category"] = {}
            
            collection_stats["by_category"][category] = collection_stats["by_category"].get(category, 0) + 1
            collection_stats["last_collection"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # 가끔(10번에 한번) 실제 디스크 수량과 동기화 (오차 보정)
            if collection_stats["total_collected"] % 10 == 0:
                threading.Thread(target=self._sync_stats_with_disk, daemon=True).start()
        
        # ── 일일 목표(1000개) 달성 알림 ──
        global daily_goal_notified
        if collection_stats["today_collected"] >= 1000 and not daily_goal_notified:
            add_log("ceo_01", "🏆 축하합니다! 일일 목표 달성", "오늘의 지식 1,000개 수집 완료!", "all")
            daily_goal_notified = True
            
        broadcast_event("stats", collection_stats)
        
        # ── Google Drive 동기화 (승인된 사용자들에게) ──
        try:
            users = load_users()
            for email, user_info in users.items():
                if user_info.get("approved") and user_info.get("folder_id"):
                    drive_filename = f"[{category}] {safe_title}.md"
                    if upload_to_drive(user_info["folder_id"], drive_filename, content):
                        add_log("data_01", f"☁️ Drive 동기화", f"{email[:15]}... → {safe_title[:30]}", category)
        except Exception as e:
            pass  # Drive 실패해도 수집은 계속
        
        # ── 텔레그램 알림 (100개마다) ──
        global _telegram_recent_titles
        _telegram_recent_titles.append(f"[{category}] {safe_title}")
        if collection_stats["today_collected"] % 100 == 0 and collection_stats["today_collected"] > 0:
            batch = list(_telegram_recent_titles)  # 지금까지 모은 목록 복사
            _telegram_recent_titles.clear()  # 버퍼 비우기 (다음 100개 새로 시작)
            threading.Thread(target=self._send_telegram_report, args=(batch,), daemon=True).start()
        
        return True
    
    def _send_telegram_report(self, titles):
        """텔레그램으로 100개 수집 보고 전송 (전체 목록 포함)"""
        try:
            import requests
            today = collection_stats["today_collected"]
            total = collection_stats["total_collected"]
            pct = min(100, round(today / 1000 * 100))
            
            header = f"📢 조아라 팀장입니다.\n"
            header += f"\n타스님께 수집 보고드립니다.\n"
            header += f"\n🎯 오늘 목표: {today}/1,000 ({pct}%)\n"
            header += f"📚 전체 지식: {total:,}개\n"
            header += f"\n─── 수집 목록 ({len(titles)}개) ───\n"
            
            # 전체 목록 생성
            body = ""
            for i, t in enumerate(titles, 1):
                body += f"{i}. {t[:55]}\n"
            
            footer = f"\n🕒 {datetime.datetime.now().strftime('%H:%M:%S')}"
            
            full_msg = header + body + footer
            
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            
            # 텔레그램 4096자 제한 대응: 길면 분할 전송
            if len(full_msg) <= 4000:
                for chat_id in TELEGRAM_CHAT_IDS:
                    try:
                        requests.post(url, json={"chat_id": chat_id, "text": full_msg}, timeout=10)
                    except: pass
            else:
                # 헤더 먼저
                for chat_id in TELEGRAM_CHAT_IDS:
                    try: requests.post(url, json={"chat_id": chat_id, "text": header + body[:3500] + "\n..."}, timeout=10)
                    except: pass
                # 나머지
                remaining = body[3500:]
                if remaining:
                    for chat_id in TELEGRAM_CHAT_IDS:
                        try: requests.post(url, json={"chat_id": chat_id, "text": "...(이어서)\n" + remaining + footer}, timeout=10)
                        except: pass
            
            add_log("research_01", "📨 텔레그램 보고 전송 완료", f"오늘 {today}개 / 목표 1,000 ({len(titles)}건 목록)")
        except Exception as e:
            add_log("research_01", "⚠️ 텔레그램 전송 실패", str(e)[:50])

    def execute_direct_order(self, member_id: str, command: str):
        """사용자의 직접 명령 이행 및 보고서 작성"""
        # 해당 사원 정보 찾기
        member_info = None
        target_cat = "all"
        for k, v in TEAM_STRUCTURE.items():
            if v["id"] == member_id:
                member_info = v
                # 해당 멤버의 팀/카테고리 유추
                if "research" in k: target_cat = "science" if "01" in v["id"] else "tech"
                break
        
        if not member_info:
            return {"status": "error", "message": "사원을 찾을 수 없습니다."}

        add_log(member_id, "💡 직접 명령 수령", command, target_cat)
        
        report = {
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "member_name": member_info["name"],
            "command": command,
            "steps": [],
            "result": "진행 중",
            "file_path": ""
        }

        try:
            # 1. 명령 분석 (URL인지 키워드인지)
            is_url = "youtube.com" in command or "youtu.be" in command
            
            if is_url:
                report["steps"].append("1. 유튜브 URL 분석 및 영상 정보 추출 시작")
                video_id_match = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11}).*', command)
                if not video_id_match: raise Exception("유효하지 않은 URL")
                v_id = video_id_match.group(1)
                
                import yt_dlp
                with yt_dlp.YoutubeDL({'quiet': True, 'extractor_args': {'youtube': {'player_client': ['android_vr']}}}) as ydl:
                    info = ydl.extract_info(command, download=False)
                    title = info.get('title', '제목 없음')
                report["steps"].append(f"2. 영상 제목 확인: {title}")
            else:
                report["steps"].append(f"1. 키워드 '{command}'로 자율 탐색 시작")
                search_query = f"ytsearch1:{command}"
                videos = self.collect_channel_videos(search_query, target_cat, max_videos=1)
                if not videos: raise Exception("검색 결과 없음")
                video = videos[0]
                v_id = video.get('id')
                title = video.get('title', '제목 없음')
                report["steps"].append(f"2. 가장 관련성 높은 영상 발견: {title}")

            # 2. 자막 수집
            report["steps"].append("3. 자막 데이터 수집 및 청크 분석 중")
            transcript = self.get_transcript(v_id, target_cat)
            if not transcript: raise Exception("자막 수집 실패")
            
            # 3. AI 지식화
            report["steps"].append(f"4. AI 모델({self.current_model})로 지식 문서화 진행")
            md_content = self.process_with_gemini(title, transcript, target_cat, v_id)
            
            # 4. 저장
            report["steps"].append("5. 최종 보고서(Markdown) 파일 저장 중")
            if self.save_document(title, md_content, target_cat):
                self.processed_ids.add(v_id)
                self._save_processed_ids()
                report["result"] = f"✅ 지시하신 업무를 성공적으로 완료했습니다! (현재 총 {collection_stats['total_collected']}개의 지식 보유)"
                report["file_path"] = f"{target_cat}/{title}.md"
                add_log(member_id, "🎯 직접 지시 이행 완료", f"총 {collection_stats['total_collected']}개 지식 수집됨", target_cat)
            else:
                report["result"] = "⚠️ 이미 존재하는 지식입니다."
                
        except Exception as e:
            report["result"] = f"❌ 이행 실패: {str(e)}"
            report["steps"].append(f"⚠️ 오류 발생: {str(e)}")

        report["total_at_time"] = collection_stats["total_collected"]
        return report

    def process_category(self, cat_key, cat_info):
        add_log("ceo_01", f"[{cat_info['name']}] 수집 지시", "해당 팀 탐색 시작", cat_key)
        
        sources_to_check = list(cat_info.get("channels", []))
        
        # 항상 키워드 검색 2~3개 추가 (새 영상 발견율 극대화)
        if cat_info.get("keywords"):
            picks = random.sample(cat_info["keywords"], min(3, len(cat_info["keywords"])))
            for keyword in picks:
                search_query = f"ytsearch50:{keyword}"
                sources_to_check.append(search_query)
            add_log("research_01", "🚀 키워드 탐색", f"{', '.join(picks)[:60]}", cat_key)
            
        if not sources_to_check:
            return

        consecutive_429 = 0  # 429 오류 연속 카운터
            
        for source_url in sources_to_check:
            if self._stop_event.is_set():
                break
            
            # 소스명 추출 (디버깅/로그용)
            src_name = source_url.split('@')[-1].split('/')[0] if '@' in source_url else "검색결과"
            add_log("research_01", f"📡 소스 스캔 중", f"@{src_name}", cat_key)
            
            try:
                videos = self.collect_channel_videos(source_url, cat_key, max_videos=50)
                
                skipped = 0
                for video in videos:
                    if self._stop_event.is_set():
                        break
                    
                    v_id = video.get('id')
                    title = video.get('title', f'video_{v_id}')
                    
                    with self.lock:
                        if v_id in self.processed_ids:
                            skipped += 1
                            continue
                            
                    safe_t = re.sub(r'[<>:"/\\|?*]', '', title)[:80]
                    today_str = datetime.datetime.now().strftime("%Y-%m-%d")
                    if (KNOWLEDGE_DIR / today_str / cat_key / f"{safe_t}.md").exists():
                        with self.lock:
                            self.processed_ids.add(v_id)
                        skipped += 1
                        continue
                    
                    if skipped > 0:
                        add_log("research_02", f"⏩ {skipped}개 기수집 스킵", "", cat_key)
                        skipped = 0
                    add_log("research_01", f"영상 처리 시작", title[:50], cat_key)
                    self.last_heartbeat = time.time()  # 탐색 시작 전 하트비트
                    
                    transcript = self.get_transcript(v_id, cat_key, title=title)
                    self.last_heartbeat = time.time()  # 자막 수집 후 하트비트
                    if not transcript:
                        # 실패 횟수 기록 (3번까지 재시도 허용)
                        fail_count = self.failed_ids.get(v_id, 0) + 1
                        self.failed_ids[v_id] = fail_count
                        if fail_count >= 3:
                            with self.lock:
                                self.processed_ids.add(v_id)  # 3번 실패 → 영구 스킵
                                self._save_processed_ids()
                            add_log("qa_01", f"⛔ 3회 실패, 영구 스킵", title[:40], cat_key)
                        consecutive_429 += 1
                        if consecutive_429 >= 3:
                            add_log("qa_01", "⏸️ YouTube 요청 제한 감지, 60초 대기", f"{cat_key} 카테고리", cat_key)
                            time.sleep(60)
                            consecutive_429 = 0
                        continue
                    
                    consecutive_429 = 0
                    # 실패 기록 초기화
                    if v_id in self.failed_ids:
                        del self.failed_ids[v_id]
                    
                    self.last_heartbeat = time.time()  # 분석 시작 전 하트비트
                    md_content = self.process_with_gemini(title, transcript, cat_key, v_id)
                    self.last_heartbeat = time.time()  # 분석 완료 후 하트비트
                    if md_content:
                        add_log("qa_01", "✅ 품질 검사 통과", title[:40], cat_key)
                        with self.lock:
                            if self.save_document(title, md_content, cat_key):
                                self.processed_ids.add(v_id)
                                self._save_processed_ids()
                                add_log("intern_01", "💾 파일 정리 완료", title[:40], cat_key)
                    else:
                        add_log("qa_02", "⚠️ 분석 결과 부적합", title[:40], cat_key)
                    
                    # 수집 속도: 2~3초 대기
                    delay = random.randint(2, 3)
                    for _ in range(delay):
                        if self._stop_event.is_set(): break
                        time.sleep(1)
                    
            except Exception as e:
                add_log("qa_02", "오류 발생", str(e)[:100], cat_key)
        
            # 2초 대기
            for _ in range(2):
                if self._stop_event.is_set(): break
                time.sleep(1)

    def run_collection_cycle(self):
        """하나의 수집 사이클 실행 (카테고리를 3개씩 배치로 동시 실행)"""
        add_log("ceo_01", "🏢 수집 사이클 시작", "카테고리 배치 가동")
        self._cleanup_old_audio()
        
        cat_items = list(CATEGORIES.items())
        batch_size = 3
        for i in range(0, len(cat_items), batch_size):
            if self._stop_event.is_set(): break
            batch = cat_items[i:i+batch_size]
            threads = []
            for cat_key, cat_info in batch:
                if self._stop_event.is_set(): break
                t = threading.Thread(target=self.process_category, args=(cat_key, cat_info))
                threads.append(t)
                t.start()
                time.sleep(1)
            for t in threads:
                t.join() # 타임아웃 없이 확실히 완료될 때까지 대기
                if self._stop_event.is_set(): break
            if not self._stop_event.is_set() and i + batch_size < len(cat_items):
                add_log("ceo_01", "⏳ 다음 배치 준비 중", f"{min(i+batch_size, len(cat_items))}/{len(cat_items)} 완료")
                for _ in range(15):
                    if self._stop_event.is_set(): break
                    time.sleep(1)
        if not self._stop_event.is_set():
            add_log("ceo_01", "✅ 수집 사이클 완료", f"총 {collection_stats['total_collected']}건 누적 수집됨")

    def _sync_stats_with_disk(self):
        """실제 디스크 파일을 전수 조사하여 메모리상의 통계를 보정 (백그라운드 실행)"""
        try:
            temp_by_cat = {}
            total = 0
            for cat_name in CATEGORIES:
                cat_files = list(KNOWLEDGE_DIR.glob(f"**/{cat_name}/*.md"))
                count = len(cat_files)
                temp_by_cat[cat_name] = count
                total += count
            
            all_md = list(KNOWLEDGE_DIR.glob("**/*.md"))
            real_total = len(all_md)
            
            with self.lock:
                collection_stats["by_category"].update(temp_by_cat)
                collection_stats["total_collected"] = real_total
                broadcast_event("stats", collection_stats)
        except:
            pass

    def _cleanup_old_audio(self):
        """임시 미디어 파일 정리"""
        cleaned = 0
        try:
            for ext in ["audio_*.*", "*.vtt", "*.m4a", "*.webm", "*.opus", "*.mp3"]:
                for f in BASE_DIR.glob(ext):
                    if f.stat().st_mtime < time.time() - 300:
                        f.unlink()
                        cleaned += 1
            if cleaned > 0: add_log("qa_02", f"🧹 임시 파일 {cleaned}개 정리 완료", "디스크 보호")
        except: pass

collector = YouTubeCollector()

def background_worker():
    collector.running = True
    collector._stop_event.clear()
    collector.last_heartbeat = time.time()
    collection_stats["is_running"] = True
    broadcast_event("status", {"running": True})
    while not collector._stop_event.is_set():
        try:
            collector.last_heartbeat = time.time()
            _check_daily_reset()  # 자정 리셋 체크
            _check_scheduled_messages()  # 점심/퇴근 알림 체크
            collector.run_collection_cycle()
        except Exception as e:
            add_log("ceo_01", "⚠️ 시스템 오류, 5초 후 재시도", str(e)[:80])
            time.sleep(5)  # 빠르게 복구
        if collector._stop_event.is_set(): break
        collector.last_heartbeat = time.time()
        add_log("ceo_01", "⏳ 다음 수집까지 5초 대기", "팀원들 준비 중...")
        for _ in range(5):
            if collector._stop_event.is_set(): break
            time.sleep(1)
    collector.running = False
    collection_stats["is_running"] = False
    broadcast_event("status", {"running": False})
    add_log("ceo_01", "🛑 수집 시스템 중지됨", "")

def _check_daily_reset():
    """자정이 지나면 오늘 수집량을 0으로 초기화"""
    global _last_daily_reset, daily_goal_notified, _telegram_recent_titles
    today_str = datetime.datetime.now().strftime("%Y-%m-%d")
    if today_str != _last_daily_reset:
        _last_daily_reset = today_str
        collection_stats["today_collected"] = 0
        daily_goal_notified = False
        _telegram_recent_titles = []
        add_log("ceo_01", "🌅 새로운 하루 시작!", f"오늘의 목표: 1,000개 수집")
        broadcast_event("stats", collection_stats)

_scheduled_sent = {}  # {"2026-05-08_12": True, "2026-05-08_18": True}

def _check_scheduled_messages():
    """정해진 시간에 텔레그램 알림 전송 (점심 12시, 퇴근 18시)"""
    import requests
    now = datetime.datetime.now()
    today = now.strftime("%Y-%m-%d")
    hour = now.hour
    
    schedules = {
        12: "🍱 조아라 팀장입니다.\n\n(주)타스 사원 여러분, 점심 먹을 시간입니다!\n잠시 쉬시고 오세요~ 😊\n\n📊 현재까지 오늘 수집: {today_count}개 / 1,000\n🕐 12:00",
        18: "🏠 조아라 팀장입니다.\n\n(주)타스 사원 여러분, 퇴근 시간입니다!\n오늘도 수고하셨습니다~ 👏\n\n📊 오늘 수집 결과: {today_count}개 / 1,000 ({pct}%)\n📚 전체 지식: {total}개\n🕕 18:00",
    }
    
    for sched_hour, msg_template in schedules.items():
        key = f"{today}_{sched_hour}"
        if hour == sched_hour and key not in _scheduled_sent:
            _scheduled_sent[key] = True
            today_count = collection_stats.get("today_collected", 0)
            total = collection_stats.get("total_collected", 0)
            pct = min(100, round(today_count / 1000 * 100))
            msg = msg_template.format(today_count=today_count, total=f"{total:,}", pct=pct)
            
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            for chat_id in TELEGRAM_CHAT_IDS:
                try:
                    requests.post(url, json={"chat_id": chat_id, "text": msg}, timeout=10)
                except: pass
            add_log("research_01", f"📨 정시 알림 전송", f"{sched_hour}시 알림")

def watchdog_worker():
    global worker_thread
    while True:
        time.sleep(30)  # 30초마다 체크
        if collector._manual_stop: continue
        if collector.running:
            elapsed = time.time() - collector.last_heartbeat
            if elapsed > 600:  # 10분 무응답 시 재시작 (GPT-OSS 클라우드 모델은 느림)
                add_log("ceo_01", "🐕 워치독: 응답 없음 감지! 재시작", f"무응답 {int(elapsed)}초")
                collector.stop()
                time.sleep(3)
                collector._manual_stop = False
                worker_thread = threading.Thread(target=background_worker, daemon=True)
                worker_thread.start()
        else:
            if not collector._manual_stop:
                add_log("ceo_01", "🐕 워치독: 워커 정지 감지, 자동 재시작", "")
                collector._stop_event.clear()
                worker_thread = threading.Thread(target=background_worker, daemon=True)
                worker_thread.start()

worker_thread: Optional[threading.Thread] = None
watchdog_thread: Optional[threading.Thread] = None
SHARED_PAGE_HTML = """<!DOCTYPE html>
<html lang="ko"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>🌐 Knowledge Hub — 지식 공유 플랫폼</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Outfit:wght@500;700&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#0f172a;color:#f8fafc;min-height:100vh;overflow-x:hidden}
.bg-glow{position:fixed;width:400px;height:400px;border-radius:50%;filter:blur(120px);opacity:0.12;pointer-events:none;z-index:0}
.bg1{top:-100px;left:-100px;background:#38bdf8}.bg2{bottom:-100px;right:-100px;background:#a855f7}.bg3{top:50%;left:50%;background:#10b981}

/* Login */
.login-wrap{display:flex;align-items:center;justify-content:center;min-height:100vh}
.card{background:rgba(30,41,59,0.9);backdrop-filter:blur(20px);border:1px solid rgba(56,189,248,0.2);border-radius:24px;padding:48px;width:480px;box-shadow:0 25px 60px rgba(0,0,0,0.5);position:relative;z-index:10}
h1{font-family:'Outfit',sans-serif;font-size:28px;color:#38bdf8;margin-bottom:8px;text-align:center}
.subtitle{color:#94a3b8;font-size:14px;text-align:center;margin-bottom:32px}
label{font-size:12px;font-weight:600;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;display:block;margin-bottom:6px;margin-top:18px}
input{width:100%;padding:14px 16px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.1);border-radius:12px;color:#fff;font-size:15px;outline:none;transition:border 0.3s}
input:focus{border-color:#38bdf8;box-shadow:0 0 0 3px rgba(56,189,248,0.15)}
.btn{width:100%;padding:16px;background:linear-gradient(135deg,#38bdf8,#818cf8);border:none;border-radius:12px;color:#fff;font-size:16px;font-weight:700;cursor:pointer;margin-top:28px;transition:transform 0.2s,box-shadow 0.2s}
.btn:hover{transform:translateY(-2px);box-shadow:0 8px 30px rgba(56,189,248,0.3)}
.btn:disabled{opacity:0.5;cursor:not-allowed;transform:none}
.info-box{background:rgba(56,189,248,0.1);border:1px solid rgba(56,189,248,0.3);border-radius:12px;padding:16px;margin-top:24px;font-size:13px;color:#94a3b8;line-height:1.6}
.info-box code{background:rgba(255,255,255,0.1);padding:2px 8px;border-radius:4px;color:#38bdf8;font-size:11px;word-break:break-all}
.status-msg{text-align:center;margin-top:20px;font-size:14px;font-weight:600;padding:12px;border-radius:8px;display:none}
.status-msg.pending{display:block;background:rgba(245,158,11,0.15);color:#f59e0b;border:1px solid rgba(245,158,11,0.3)}
.status-msg.error{display:block;background:rgba(239,68,68,0.15);color:#ef4444;border:1px solid rgba(239,68,68,0.3)}

/* Dashboard */
#dashboard{display:none;padding:24px;max-width:1200px;margin:0 auto;position:relative;z-index:10}
.dash-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;background:rgba(30,41,59,0.8);padding:16px 24px;border-radius:16px;border:1px solid rgba(56,189,248,0.2)}
.dash-header h2{font-family:'Outfit',sans-serif;color:#38bdf8;font-size:20px}
.office-wrap{background:#000;border-radius:20px;overflow:hidden;margin-bottom:24px;height:400px;position:relative;border:1px solid rgba(56,189,248,0.2);display:flex;align-items:center;justify-content:center}
.office-map{width:1000px;height:750px;transform-origin:center;position:relative;background-image:url('/static/images/office.jpg');background-size:cover}
.employee{position:absolute;width:65px;height:100px;background-image:url('/static/images/characters.png');background-size:500% 200%;transform:translate(-50%,-50%);transition:all 0.5s ease;z-index:5}
.employee.working{animation:bounce 0.5s infinite alternate}
@keyframes bounce{0%{transform:translate(-50%,-50%)}100%{transform:translate(-50%,-60%);filter:drop-shadow(0 10px 15px var(--emp-color))}}
.employee-label{position:absolute;bottom:-45px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.8);padding:4px 8px;border-radius:6px;font-size:10px;font-weight:600;text-align:center;border:1px solid rgba(255,255,255,0.1);white-space:nowrap}
.task-bubble{position:absolute;top:-50px;left:50%;transform:translateX(-50%) scale(0);background:#fff;color:#000;padding:6px 12px;border-radius:12px;font-size:10px;font-weight:800;white-space:nowrap;z-index:10;border:2px solid var(--emp-color);opacity:0;transition:all 0.3s}
.task-bubble.show{transform:translateX(-50%) scale(1);opacity:1}

.main-grid{display:grid;grid-template-columns:1fr 350px;gap:24px}
.stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:16px}
.stat-box{background:rgba(30,41,59,0.8);border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:20px;text-align:center}
.stat-box .num{font-family:'Outfit',sans-serif;font-size:32px;font-weight:800;background:linear-gradient(135deg,#38bdf8,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.stat-box .label{color:#94a3b8;font-size:11px;margin-top:4px;text-transform:uppercase}
.log-panel{background:rgba(30,41,59,0.8);border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:20px;height:400px;display:flex;flex-direction:column}
.log-panel h3{font-size:16px;color:#38bdf8;margin-bottom:12px}
#log-list{flex:1;overflow-y:auto;font-family:monospace;font-size:11px}
.log-entry{padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.04);display:flex;gap:10px}
.log-entry .time{color:#475569}
.log-entry .name{font-weight:700;color:#818cf8}
.log-entry .act{color:#38bdf8}
.log-entry .det{color:#64748b;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cat-list{list-style:none}
.cat-item{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.04);font-size:12px}
.cat-item strong{color:#38bdf8}
.download-btn{background:linear-gradient(135deg,#10b981,#059669);border:none;color:#fff;padding:10px 20px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;transition:all 0.2s}
.download-btn:hover{transform:translateY(-2px);box-shadow:0 8px 25px rgba(16,185,129,0.3)}
</style></head><body>
<div class="bg-glow bg1"></div><div class="bg-glow bg2"></div><div class="bg-glow bg3"></div>

<!-- LOGIN -->
<div class="login-wrap" id="login-view">
<div class="card">
<h1>🌐 Knowledge Hub</h1>
<p class="subtitle">AI 지식 수집 시스템에 연결하세요</p>
<label>📧 이메일 주소</label>
<input type="email" id="email" placeholder="your@email.com">
<label>📁 구글드라이브 폴더 링크 (선택사항)</label>
<input type="url" id="drive_url" placeholder="https://drive.google.com/drive/folders/...">
<div class="info-box">
<strong>📌 안내:</strong>
<ul class="steps" style="font-size:12px; margin-top:8px; list-style:disc; padding-left:16px;">
<li>드라이브 링크는 비워두셔도 되지만, 연동 시 실시간 동기화됩니다.</li>
<li id="service-email-display">서비스 이메일: <code>loading...</code></li>
</ul></div>
<button class="btn" id="submit-btn" onclick="register()">🚀 접속 신청하기</button>
<div class="status-msg" id="status-msg"></div>
</div>
</div>

<div id="dashboard">
<div class="dash-header">
    <h2>🏢 Knowledge Collection Office</h2>
    <div style="display:flex; align-items:center; gap:16px;">
        <div class="stat-box" style="padding:4px 12px; height:auto; margin:0; min-width:auto;">
            <div class="num" id="personal-count" style="font-size:18px;">0</div>
            <div class="label" style="font-size:9px;">New Discoveries</div>
        </div>
        <button class="download-btn" onclick="downloadPersonal()">📥 Download My Data</button>
        👤 <span id="dash-email"></span>
    </div>
</div>
<div class="office-wrap"><div class="office-map" id="office-map"></div></div>
<div class="stats-row">
    <div class="stat-box"><div class="num" id="s-total">0</div><div class="label">Total Knowledge</div></div>
    <div class="stat-box"><div class="num" id="s-today">0</div><div class="label">Today Collected</div></div>
    <div class="stat-box"><div class="num" id="s-status">—</div><div class="label">System Status</div></div>
</div>
<div class="main-grid">
    <div class="log-panel"><h3>📋 실시간 수집 로그</h3><div id="log-list"></div></div>
    <div class="side-panel">
        <div class="stat-box" style="text-align:left; padding:16px; margin-bottom:16px;">
            <h3 style="font-size:14px; color:#a855f7; margin-bottom:12px;">📅 Daily Collection</h3>
            <div id="date-list"></div>
        </div>
        <div class="stat-box" style="text-align:left; padding:16px;">
            <h3 style="font-size:14px; color:#38bdf8; margin-bottom:12px;">📁 Categories</h3>
            <div id="cat-list"></div>
        </div>
    </div>
</div>
</div>

<script>
let userEmail = '';
let teamData = {};
const customPositions = {
    "ceo_01": { x: 17, y: 19 }, "research_01": { x: 49, y: 19 }, "qa_01": { x: 88, y: 39 },
    "research_02": { x: 27, y: 45 }, "research_03": { x: 27, y: 55 },
    "data_01": { x: 45, y: 60 }, "data_02": { x: 45, y: 50 },
    "qa_02": { x: 91, y: 72 }, "intern_01": { x: 10, y: 82 }
};

async function loadServiceEmail(){
    try{const r=await fetch('/api/users/service-email');const d=await r.json();
    document.getElementById('service-email-display').innerHTML='서비스 이메일: <code>'+d.email+'</code>';}catch(e){}
}

async function register(){
    const email=document.getElementById('email').value.trim();
    const drive_url=document.getElementById('drive_url').value.trim();
    const btn=document.getElementById('submit-btn');
    const msg=document.getElementById('status-msg');
    if(!email){msg.className='status-msg error';msg.textContent='이메일을 입력하세요';return}
    btn.disabled=true;btn.textContent='처리 중...';
    try{
        const r=await fetch('/api/users/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,drive_url})});
        const d=await r.json();
        if(d.error){msg.className='status-msg error';msg.textContent=d.error;btn.disabled=false;btn.textContent='🚀 접속 신청하기';return}
        if(d.status==='already_approved'){showDashboard(email)}
        else{msg.className='status-msg pending';msg.textContent='⏳ '+d.message;startPolling(email)}
    }catch(e){msg.className='status-msg error';msg.textContent='서버 연결 실패';btn.disabled=false;btn.textContent='🚀 접속 신청하기'}
}

function startPolling(email){
    setInterval(async()=>{
        try{const r=await fetch('/api/users/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})});
        const d=await r.json(); if(d.status==='approved'){location.reload()}}catch(e){}
    },5000);
}

async function showDashboard(email){
    userEmail = email;
    document.getElementById('login-view').style.display='none';
    document.getElementById('dashboard').style.display='block';
    document.getElementById('dash-email').textContent=email;
    
    // 세션 연결 및 카운터 시작
    try {
        await fetch('/api/users/connect', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email})});
    } catch(e) {}
    
    await initOffice();
    await loadStats();
    await loadRecentLogs();
    connectSSE();
    setInterval(loadStats, 10000);
    setInterval(checkPersonalCount, 3000);
}

async function checkPersonalCount() {
    try {
        const r = await fetch('/api/users/heartbeat', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email: userEmail})});
        const d = await r.json();
        document.getElementById('personal-count').textContent = d.personal_count || 0;
    } catch(e) {}
}

async function initOffice(){
    const res=await fetch('/api/team'); teamData=await res.json();
    const map=document.getElementById('office-map'); map.innerHTML='';
    Object.values(teamData).forEach(emp=>{
        const pos=customPositions[emp.id]||{x:50,y:50};
        const div=document.createElement('div'); div.className='employee'; div.id='emp-'+emp.id;
        div.style.left=pos.x+'%'; div.style.top=pos.y+'%'; div.style.setProperty('--emp-color',emp.color);
        const x=(emp.avatar_idx%5)*25; const y=Math.floor(emp.avatar_idx/5)*100;
        div.style.backgroundPosition=`${x}% ${y}%`;
        div.innerHTML=`<div class="employee-label">${emp.name}</div><div class="task-bubble" id="bubble-${emp.id}"></div>`;
        map.appendChild(div);
    });
}

async function loadStats(){
    try{
        const r=await fetch('/api/stats');const d=await r.json();
        document.getElementById('s-total').textContent=(d.total_collected||0).toLocaleString();
        document.getElementById('s-today').textContent=(d.today_collected||0).toLocaleString();
        document.getElementById('s-status').textContent=d.is_running?'수집중':'대기';
        document.getElementById('s-status').style.color=d.is_running?'#10b981':'#f59e0b';
        
        const excludeCats = ['obsidean', '테스트', '소설수집', '스토리', 'all', '260506', '260507'];
        const cl=document.getElementById('cat-list');
        cl.innerHTML=Object.entries(d.by_category||{}).filter(([k])=>!excludeCats.includes(k)).map(([k,v])=>`<div class="cat-item"><span>${k}</span><strong>${v}</strong></div>`).join('');
        
        const excludeDates = ['2026-05-06', '2026-05-07'];
        const dl=document.getElementById('date-list');
        if(dl && d.by_date) dl.innerHTML=Object.entries(d.by_date).filter(([k])=>!excludeDates.includes(k)).map(([k,v])=>`<div class="cat-item"><span>${k}</span><strong style="color:#a855f7">${v}</strong></div>`).join('');
    }catch(e){}
}

function connectSSE(){
    const es=new EventSource('/api/events');
    es.onmessage=function(e){
        try{
            const d=JSON.parse(e.data);
            if(d.type==='log'){addLog(d.data); animateEmployee(d.data);}
            else if(d.type==='stats'){loadStats();}
        }catch(ex){}
    };
    es.onerror=function(){es.close(); setTimeout(connectSSE,5000)};
}

function animateEmployee(log){
    if(!log.member_id)return;
    const el=document.getElementById('emp-'+log.member_id);
    const b=document.getElementById('bubble-'+log.member_id);
    if(el&&b){
        el.classList.add('working'); b.innerText=log.action; b.classList.add('show');
        setTimeout(()=>{el.classList.remove('working'); b.classList.remove('show')},4000);
    }
}

function addLog(entry){
    const list=document.getElementById('log-list');
    const div=document.createElement('div'); div.className='log-entry';
    const t=entry.timestamp?entry.timestamp.split(' ')[1]||'':'';
    div.innerHTML=`<span class="time">${t}</span><span class="name">${entry.member_name||''}</span><span class="act">${entry.action||''}</span><span class="det" title="${entry.detail||''}">${entry.detail||''}</span>`;
    list.insertBefore(div,list.firstChild);
    if(list.children.length>100)list.removeChild(list.lastChild);
}

function downloadPersonal(){ 
    if(!userEmail) return;
    window.location.href=`/api/download/personal?email=${encodeURIComponent(userEmail)}`; 
}
window.onload=loadServiceEmail;
</script>"""
# ── FastAPI 앱 ──
app = FastAPI(title="YouTube Knowledge Office")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

@app.on_event("startup")
async def on_startup():
    global _main_loop
    _main_loop = asyncio.get_event_loop()

@app.get("/", response_class=HTMLResponse)
async def index():
    html_path = STATIC_DIR / "index.html"
    if html_path.exists():
        return HTMLResponse(html_path.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>Loading...</h1>")

@app.get("/api/team")
async def get_team():
    return TEAM_STRUCTURE

@app.get("/api/categories")
async def get_categories():
    return CATEGORIES

@app.get("/api/stats")
async def get_stats():
    # 실제 파일 수 재집계 — 모든 .md 파일을 카운트
    total = 0
    by_category = {}
    by_date = {}
    
    # 모든 .md 파일 검색
    all_md = list(KNOWLEDGE_DIR.glob("**/*.md"))
    total = len(all_md)
    
    for p in all_md:
        if "archive" in str(p): continue
        
        # 카테고리 추출 (부모 디렉토리 이름)
        cat = p.parent.name
        by_category[cat] = by_category.get(cat, 0) + 1
        
        # 날짜 추출 (조부모 디렉토리 이름 - YYYY-MM-DD 형식인지 확인)
        date_str = p.parent.parent.name
        if re.match(r'\d{4}-\d{2}-\d{2}', date_str):
            by_date[date_str] = by_date.get(date_str, 0) + 1
    
    # 오늘 수집량 계산
    today_str = datetime.datetime.now().strftime("%Y-%m-%d")
    today_files = [p for p in all_md if today_str in str(p)]
    
    # 글로벌 상태 업데이트
    collection_stats["total_collected"] = total
    collection_stats["today_collected"] = len(today_files)
    collection_stats["by_category"] = by_category
    collection_stats["by_date"] = dict(sorted(by_date.items(), reverse=True)[:10])
    
    return collection_stats

@app.get("/api/logs")
async def get_logs(limit: int = 100):
    return activity_log[-limit:]

@app.get("/api/knowledge/{category}")
async def get_knowledge(category: str):
    cat_dir = KNOWLEDGE_DIR / category
    if not cat_dir.exists():
        return []
    files = []
    for f in sorted(cat_dir.glob("*.md"), key=lambda x: x.stat().st_mtime, reverse=True):
        files.append({
            "name": f.stem,
            "size": f.stat().st_size,
            "modified": datetime.datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
        })
    return files

@app.get("/api/knowledge/{category}/{filename}")
async def get_knowledge_file(category: str, filename: str):
    file_path = KNOWLEDGE_DIR / category / f"{filename}.md"
    if file_path.exists():
        return {"content": file_path.read_text(encoding="utf-8")}
    return {"content": "파일을 찾을 수 없습니다."}

@app.post("/api/start")
async def start_collection():
    global worker_thread
    if collector.running:
        return {"status": "already_running"}
    
    collector._manual_stop = False  # 수동 정지 해제
    worker_thread = threading.Thread(target=background_worker, daemon=True)
    worker_thread.start()
    return {"status": "started"}

@app.post("/api/stop")
async def stop_collection():
    # 무조건 먼저 플래그 설정 — 워치독 재시작 차단
    collector._manual_stop = True
    collector._stop_event.set()
    collector.running = False
    collection_stats["is_running"] = False
    broadcast_event("status", {"running": False})
    add_log("ceo_01", "🛑 수동 정지 명령 수신", "워치독 재시작 차단됨")
    return {"status": "stopped"}

@app.get("/api/events")
async def sse_endpoint(request: Request):
    q = asyncio.Queue()
    sse_clients.append(q)
    
    async def event_generator():
        yield f"retry: 5000\n\n"  # 재접속 간격 5초
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=3.0)
                    yield f"data: {msg}\n\n"
                except asyncio.TimeoutError:
                    yield f": heartbeat\n\n"
                except Exception:
                    await asyncio.sleep(0.3)
        finally:
            if q in sse_clients:
                sse_clients.remove(q)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}
    )

from pydantic import BaseModel

class CategoryConfig(BaseModel):
    id: str
    name: str
    keywords: str
    channels: str

@app.post("/api/categories")
async def add_category(cat: CategoryConfig):
    CATEGORIES[cat.id] = {
        "name": cat.name,
        "keywords": [k.strip() for k in cat.keywords.split(",") if k.strip()],
        "channels": [c.strip() for c in cat.channels.split("\n") if c.strip()]
    }
    if cat.id not in collection_stats["by_category"]:
        collection_stats["by_category"][cat.id] = 0
    
    add_log("ceo_01", "새 카테고리 추가됨", f"{cat.name} ({cat.id})")
    return {"status": "ok", "categories": CATEGORIES}

# ── 메인 ──
@app.post("/api/settings/model")
async def update_model(request: Request):
    data = await request.json()
    model = data.get("model")
    if model:
        collector.current_model = model
        add_log("system", f"분석 모델 변경됨: {model}", "System", "All")
        return {"status": "success", "model": model}
    return JSONResponse({"status": "error"}, status_code=400)

@app.get("/api/settings/model")
async def get_current_model():
    return {"model": collector.current_model}

@app.post("/api/order")
async def direct_order(request: Request):
    data = await request.json()
    member_id = data.get("member_id")
    command = data.get("command")
    
    if not member_id or not command:
        return JSONResponse({"error": "사원 ID와 명령어가 필요합니다."}, status_code=400)
    
    report = collector.execute_direct_order(member_id, command)
    return report

# ── 사용자 관리 API ──
@app.post("/api/users/register")
async def register_user(request: Request):
    """외부 사용자 등록 (이메일 + 구글드라이브 폴더)"""
    data = await request.json()
    email = data.get("email", "").strip().lower()
    drive_url = data.get("drive_url", "").strip()
    
    if not email or "@" not in email:
        return JSONResponse({"error": "유효한 이메일을 입력하세요"}, status_code=400)
    
    # 구글 드라이브 링크를 진짜 선택사항으로 변경
    folder_id = ""
    if drive_url:
        folder_id = extract_folder_id(drive_url)
        if not folder_id:
            return JSONResponse({"error": "유효한 구글드라이브 폴더 링크가 아닙니다"}, status_code=400)
    
    users = load_users()
    if email in users and users[email].get("approved"):
        return {"status": "already_approved", "message": "이미 승인된 계정입니다!"}
    
    users[email] = {
        "email": email,
        "drive_url": drive_url,
        "folder_id": folder_id,
        "approved": False,
        "registered_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    save_users(users)
    add_log("ceo_01", f"📩 신규 가입 요청", f"{email}", "system")
    return {"status": "pending", "message": "관리자 승인을 기다려주세요!"}

@app.get("/api/users")
async def list_users():
    """관리자용: 전체 사용자 목록"""
    return load_users()

@app.post("/api/users/approve")
async def approve_user(request: Request):
    """관리자: 사용자 승인"""
    data = await request.json()
    email = data.get("email", "").strip().lower()
    users = load_users()
    if email not in users:
        return JSONResponse({"error": "사용자 없음"}, status_code=404)
    users[email]["approved"] = True
    users[email]["approved_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    save_users(users)
    add_log("ceo_01", f"✅ 사용자 승인", email, "system")
    return {"status": "approved", "email": email}

@app.post("/api/users/reject")
async def reject_user(request: Request):
    """관리자: 사용자 거부/삭제"""
    data = await request.json()
    email = data.get("email", "").strip().lower()
    users = load_users()
    if email in users:
        del users[email]
        save_users(users)
    return {"status": "removed", "email": email}

@app.post("/api/users/check")
async def check_user(request: Request):
    """사용자 상태 확인"""
    data = await request.json()
    email = data.get("email", "").strip().lower()
    users = load_users()
    if email not in users:
        return {"status": "not_found"}
    user = users[email]
    return {"status": "approved" if user.get("approved") else "pending", "email": email}

@app.get("/api/download/all")
async def download_all_knowledge():
    """전체 지식을 ZIP으로 압축하여 다운로드 후, 저장소를 비우고 0개부터 다시 시작"""
    import zipfile
    import io
    import shutil
    from starlette.responses import StreamingResponse
    
    # 1. ZIP 압축 준비
    buf = io.BytesIO()
    file_count = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(KNOWLEDGE_DIR):
            if "archive" in root: continue # 아카이브 제외
            for file in files:
                if file.endswith(".md"):
                    p = Path(root) / file
                    rel_p = p.relative_to(KNOWLEDGE_DIR)
                    zf.write(p, rel_p)
                    file_count += 1
    
    if file_count == 0:
        return JSONResponse({"error": "수집된 지식이 없습니다."}, status_code=404)

    # 2. 아카이브 폴더로 이동 (사용자 요청: 0개부터 다시 시작)
    archive_name = f"archive_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    archive_dir = KNOWLEDGE_DIR / "archive" / archive_name
    archive_dir.mkdir(parents=True, exist_ok=True)
    
    for item in KNOWLEDGE_DIR.iterdir():
        if item.name == "archive": continue
        try:
            shutil.move(str(item), str(archive_dir / item.name))
        except:
            pass
            
    # 3. 통계 초기화
    collection_stats["total_collected"] = 0
    collection_stats["today_collected"] = 0
    for cat in collection_stats["by_category"]:
        collection_stats["by_category"][cat] = 0
    
    add_log("ceo_01", "📦 지식 백업 및 초기화 완료", f"{file_count}개 파일 아카이브됨. 새 수집 시작.")
    broadcast_event("stats", collection_stats)

    buf.seek(0)
    return StreamingResponse(
        buf, 
        media_type="application/x-zip-compressed",
        headers={"Content-Disposition": f"attachment; filename=knowledge_base_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"}
    )

@app.get("/api/users/service-email")
async def get_service_email():
    """서비스 계정 이메일 반환 (사용자에게 공유 안내용)"""
    return {"email": SERVICE_ACCOUNT_EMAIL}

@app.post("/api/users/connect")
async def user_connect(request: Request):
    """사용자 대시보드 접속 — 세션 시작 시각 기록"""
    data = await request.json()
    email = data.get("email", "").strip().lower()
    now = datetime.datetime.now()
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    
    if email not in user_sessions:
        user_sessions[email] = {
            "connected_at": now_str,
            "connected_ts": now.timestamp(),
            "last_seen": now_str,
            "personal_count": 0,
        }
    else:
        user_sessions[email]["last_seen"] = now_str
    
    save_sessions(user_sessions)
    return {
        "status": "connected",
        "connected_at": user_sessions[email]["connected_at"],
        "personal_count": user_sessions[email]["personal_count"],
    }

@app.post("/api/users/heartbeat")
async def user_heartbeat(request: Request):
    """사용자 온라인 상태 유지 + 개인 통계 반환"""
    data = await request.json()
    email = data.get("email", "").strip().lower()
    now = datetime.datetime.now()
    
    if email in user_sessions:
        user_sessions[email]["last_seen"] = now.strftime("%Y-%m-%d %H:%M:%S")
        save_sessions(user_sessions)
        
        # 접속 이후 생성된 파일 수 계산
        connected_ts = user_sessions[email]["connected_ts"]
        count = 0
        for root, dirs, files in os.walk(KNOWLEDGE_DIR):
            if "archive" in root: continue
            for f in files:
                if f.endswith(".md"):
                    p = Path(root) / f
                    try:
                        if p.stat().st_mtime >= connected_ts:
                            count += 1
                    except: pass
        user_sessions[email]["personal_count"] = count
        
        return {
            "personal_count": count,
            "connected_at": user_sessions[email]["connected_at"],
        }
    return {"personal_count": 0, "connected_at": ""}

@app.get("/api/users/online")
async def get_online_users():
    """현재 접속 중인 사용자 목록 (60초 이내 하트비트)"""
    now = datetime.datetime.now()
    online = []
    for email, session in user_sessions.items():
        try:
            last = datetime.datetime.strptime(session["last_seen"], "%Y-%m-%d %H:%M:%S")
            if (now - last).total_seconds() < 60:
                online.append({
                    "email": email,
                    "connected_at": session["connected_at"],
                    "personal_count": session["personal_count"],
                })
        except: pass
    return online

@app.get("/api/download/personal")
async def download_personal_knowledge(email: str = ""):
    """해당 사용자 접속 이후 수집된 파일만 ZIP 다운로드 후 개인 카운터 초기화"""
    import zipfile
    import io
    
    email = email.strip().lower()
    if email not in user_sessions:
        return JSONResponse({"error": "세션 정보가 없습니다. 다시 접속해주세요."}, status_code=400)
    
    connected_ts = user_sessions[email]["connected_ts"]
    
    buf = io.BytesIO()
    file_count = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(KNOWLEDGE_DIR):
            if "archive" in root: continue
            for file in files:
                if file.endswith(".md"):
                    p = Path(root) / file
                    try:
                        if p.stat().st_mtime >= connected_ts:
                            rel_p = p.relative_to(KNOWLEDGE_DIR)
                            zf.write(p, rel_p)
                            file_count += 1
                    except: pass
    
    if file_count == 0:
        return JSONResponse({"error": "접속 이후 수집된 지식이 없습니다."}, status_code=404)
    
    # 개인 카운터 초기화: 접속 시간을 현재로 리셋
    now = datetime.datetime.now()
    user_sessions[email]["connected_ts"] = now.timestamp()
    user_sessions[email]["connected_at"] = now.strftime("%Y-%m-%d %H:%M:%S")
    user_sessions[email]["personal_count"] = 0
    save_sessions(user_sessions)
    
    add_log("ceo_01", f"📦 {email[:15]}... 다운로드", f"{file_count}개 파일. 개인카운터 초기화.")
    
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/x-zip-compressed",
        headers={"Content-Disposition": f"attachment; filename=knowledge_{email.split('@')[0]}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"}
    )

@app.get("/shared", response_class=HTMLResponse)
async def shared_page():
    """외부 사용자용 접속 페이지 (별도 HTML 파일)"""
    shared_path = STATIC_DIR / "shared.html"
    if shared_path.exists():
        return HTMLResponse(shared_path.read_text(encoding="utf-8"))
    return HTMLResponse(SHARED_PAGE_HTML)

if __name__ == "__main__":
    print("🏢 YouTube Knowledge Office 서버 시작...")
    print("📍 http://127.0.0.1:8000/")
    
    # 기존 knowledge 파일 수 카운트
    total_init = 0
    for cat in CATEGORIES:
        cat_files = list(KNOWLEDGE_DIR.glob(f"**/{cat}/*.md"))
        collection_stats["by_category"][cat] = len(cat_files)
        total_init += len(cat_files)
    all_md = list(KNOWLEDGE_DIR.glob("**/*.md"))
    other = len(all_md) - total_init
    if other > 0:
        collection_stats["by_category"]["기타"] = other
    collection_stats["total_collected"] = len(all_md)
    
    # 오늘 수집량 초기화 (폴더 기반)
    today_str = datetime.datetime.now().strftime("%Y-%m-%d")
    today_files = list(KNOWLEDGE_DIR.glob(f"{today_str}/**/*.md"))
    collection_stats["today_collected"] = len(today_files)
    
    print(f"📊 기존 지식: {len(all_md)}개 (오늘: {len(today_files)}개)")
    
    # 🚀 서버 시작 시 자동 수집 + 워치독 시작
    worker_thread = threading.Thread(target=background_worker, daemon=True)
    worker_thread.start()
    watchdog_thread = threading.Thread(target=watchdog_worker, daemon=True)
    watchdog_thread.start()
    print("🐕 워치독 가동 — 수집이 멈추면 자동 재시작합니다")
    
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
