@echo off
chcp 65001 >nul
echo ========================================
echo   YouTube Knowledge Office - Full Restart
echo ========================================
echo.
echo [1/3] Killing all Python processes...
taskkill /F /IM python.exe 2>nul
echo.
echo [2/3] Waiting 3 seconds for ports to free...
timeout /t 3 /nobreak >nul
echo.
echo [3/3] Installing dependencies...
py -m pip install yt-dlp youtube-transcript-api requests fastapi uvicorn aiofiles -q 2>nul
echo.
echo [4/4] Starting YouTube Office Server...
start "YouTube Office" /D "C:\Users\ppitu\.gemini\antigravity\scratch\youtube_office" py server.py
echo.
echo ========================================
echo   Server started!
echo   Internal:  http://127.0.0.1:8000/
echo   Shared:    http://127.0.0.1:8000/shared
echo ========================================
echo.
echo Press any key to close this window...
pause >nul
