"""Export YouTube cookies from Chrome/Edge to cookies.txt for yt-dlp"""
import sqlite3, os, tempfile, shutil
from pathlib import Path

output_path = Path(__file__).parent / "cookies.txt"

# 브라우저별 쿠키 DB 경로
browsers = {
    "Chrome": Path(os.environ["LOCALAPPDATA"]) / "Google" / "Chrome" / "User Data" / "Default" / "Network" / "Cookies",
    "Edge": Path(os.environ["LOCALAPPDATA"]) / "Microsoft" / "Edge" / "User Data" / "Default" / "Network" / "Cookies",
}

for name, src in browsers.items():
    if not src.exists():
        print(f"{name}: 쿠키 파일 없음")
        continue
    
    try:
        # WAL 모드로 읽기 전용 접근 (Chrome 실행 중에도 가능)
        tmp = tempfile.mktemp(suffix=".db")
        shutil.copy2(str(src), tmp)
        # WAL/SHM 파일도 복사
        for ext in ["-wal", "-shm"]:
            wal = Path(str(src) + ext)
            if wal.exists():
                shutil.copy2(str(wal), tmp + ext)
        
        conn = sqlite3.connect(f"file:{tmp}?mode=ro&nolock=1", uri=True)
        c = conn.cursor()
        
        # YouTube + Google 쿠키
        c.execute("SELECT host_key, name, path, is_secure, expires_utc, value, encrypted_value FROM cookies WHERE host_key LIKE ? OR host_key LIKE ?",
                  ("%.youtube.com", "%.google.com"))
        cookies = c.fetchall()
        conn.close()
        
        # 임시 파일 정리
        for f in [tmp, tmp+"-wal", tmp+"-shm"]:
            try: os.remove(f)
            except: pass
        
        plain_count = sum(1 for c in cookies if c[5])  # value가 있는 것
        encrypted_count = sum(1 for c in cookies if c[6] and not c[5])  # encrypted만 있는 것
        
        print(f"{name}: 총 {len(cookies)}개 쿠키 (평문: {plain_count}, 암호화: {encrypted_count})")
        
        if plain_count > 0:
            with open(str(output_path), "w") as f:
                f.write("# Netscape HTTP Cookie File\n")
                f.write(f"# Exported from {name}\n\n")
                written = 0
                for host, cname, path, secure, expires, value, enc_value in cookies:
                    if value:
                        secure_str = "TRUE" if secure else "FALSE"
                        incl_sub = "TRUE" if host.startswith(".") else "FALSE"
                        f.write(f"{host}\t{incl_sub}\t{path}\t{secure_str}\t{expires}\t{cname}\t{value}\n")
                        written += 1
            print(f"✅ {written}개 쿠키 저장 → {output_path}")
            break
        else:
            print(f"⚠️ {name}: 모든 쿠키가 암호화되어 있음 (DPAPI)")
            
    except Exception as e:
        print(f"{name} 실패: {e}")

# 쿠키 파일이 없으면 안내
if not output_path.exists():
    print("\n❌ 쿠키 내보내기 실패")
    print("Chrome에서 수동으로 내보내세요:")
    print("1. Chrome 확장 'Get cookies.txt LOCALLY' 설치")
    print("2. youtube.com 접속 후 확장에서 내보내기")
    print(f"3. 파일을 {output_path}에 저장")
