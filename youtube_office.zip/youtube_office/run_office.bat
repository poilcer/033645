@echo off
setlocal
cd /d "%~dp0"
echo Starting YouTube Knowledge Office...
start /b pythonw server.py
echo Office is running on http://127.0.0.1:8000
pause
