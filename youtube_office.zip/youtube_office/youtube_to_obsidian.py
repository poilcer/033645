import os
import sys
import json
import re
import time
import datetime
import subprocess
from pathlib import Path
from typing import Optional

# ── 환경 설정 ──
BASE_DIR = Path(__file__).parent
KNOWLEDGE_DIR = Path(r"H:\obsidean")
KNOWLEDGE_DIR.mkdir(exist_ok=True)

# .env에서 Gemini API 키 로드
GEMINI_API_KEY = ""
env_path = Path(r"h:\Users\ppitu\AppData\Local\Programs\Microsoft VS Code\chart-app\.env")
if env_path.exists():
    for line in env_path.read_text(encoding="utf-8").splitlines():
        if line.startswith("GEMINI_API_KEY="):
            GEMINI_API_KEY = line.split("=", 1)[1].strip()

def get_transcript(video_id: str):
    print(f"🔍 자막 수집 중: {video_id}")
    
    # 1) YouTubeTranscriptApi
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
        transcript_list = YouTubeTranscriptApi.fetch_transcript(video_id, languages=['ko', 'en'])
        text = " ".join([t['text'] for t in transcript_list])
        print("✅ 자막 수집 성공 (Official API)")
        return text
    except: pass
    
    # 2) yt-dlp
    try:
        print("🔄 자막 재시도 (yt-dlp)...")
        cmd = ["python", "-m", "yt_dlp", "--write-subs", "--write-auto-subs", "--sub-lang", "ko,en.*",
               "--skip-download", "--convert-subs", "vtt", "-o", f"{video_id}.%(ext)s",
               f"https://www.youtube.com/watch?v={video_id}"]
        subprocess.run(cmd, capture_output=True, text=True, cwd=str(BASE_DIR), timeout=60)
        vtt_files = list(BASE_DIR.glob(f"{video_id}*.vtt"))
        if vtt_files:
            f = next((x for x in vtt_files if '.ko.' in x.name), vtt_files[0])
            text = f.read_text(encoding='utf-8')
            clean = " ".join([l.strip() for l in text.split('\n') if '-->' not in l and l.strip() and not l.startswith(('WEBVTT', 'Kind', 'Language'))])
            clean = re.sub(r'<[^>]+>', '', clean)
            for x in vtt_files: x.unlink()
            print("✅ 자막 수집 성공 (yt-dlp)")
            return clean
    except: pass

    # 3) pytubefix
    try:
        print("🔄 자막 재시도 (pytubefix)...")
        from pytubefix import YouTube
        yt = YouTube(f"https://youtube.com/watch?v={video_id}")
        caption = yt.captions.get_by_language_code('ko') or yt.captions.get_by_language_code('a.ko') or \
                  yt.captions.get_by_language_code('en') or yt.captions.get_by_language_code('a.en')
        if caption:
            text = caption.generate_srt_captions()
            clean = re.sub(r'\d+\n\d{2}:\d{2}:\d{2},\d{3} --> \d{2}:\d{2}:\d{2},\d{3}\n', '', text)
            print("✅ 자막 수집 성공 (pytubefix)")
            return clean
    except: pass

    # 4) Whisper AI (Ultimate Fallback)
    try:
        print("🎙️ 자막이 없음. AI 음성 인식 시작 (Whisper)...")
        from faster_whisper import WhisperModel
        audio_path = BASE_DIR / f"temp_audio_{video_id}"
        cmd = ["python", "-m", "yt_dlp", "-f", "ba[ext=m4a]/ba", "-o", f"{audio_path}.%(ext)s", f"https://www.youtube.com/watch?v={video_id}"]
        subprocess.run(cmd, capture_output=True, text=True, cwd=str(BASE_DIR), timeout=180)
        audio_file = next(BASE_DIR.glob(f"temp_audio_{video_id}.*"), None)
        if audio_file:
            model = WhisperModel("tiny", device="cpu", compute_type="int8")
            segments, _ = model.transcribe(str(audio_file), beam_size=5)
            result = " ".join([s.text for s in segments])
            audio_file.unlink()
            print("✅ AI 음성 인식 성공!")
            return result
    except Exception as e:
        print(f"❌ 모든 자막 수집 방법 실패: {e}")
    return None

def process_ai(title: str, transcript: str, video_id: str):
    if not GEMINI_API_KEY:
        print("⚠️ Gemini API 키가 없습니다. 원본 텍스트만 저장합니다.")
        return f"# {title}\n\n{transcript}"
    
    print("🤖 AI 문서 생성 중...")
    import google.generativeai as genai
    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel("gemini-pro")
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    
    prompt = f"""당신은 최고의 자료 조사 AI 어시스턴트입니다.
아래 유튜브 영상 내용을 읽고, 한국어 옵시디언 지식 문서로 작성해주세요.
중요: 영어 영상이라면 한국어로 번역하여 정리해주세요.

포맷:
---
tags: [수동수집, YouTube]
date: {today}
source_url: https://www.youtube.com/watch?v={video_id}
---

# 📚 {title}

*(Source: YouTube 수동 수집)*

## 🔍 1. 핵심 방향성 및 요약
(전체 요약)

## 🛑 2. 주의사항 또는 피해야 할 점
(경고 항목)

## ✅ 3. 실행 전략 및 권장 사항
(실천 방안)

---
### 💡 주요 개념 요약 (Keywords)
* 개념: 설명

---
*Generated: {today}*

원본 데이터:
제목: {title}
자막: {transcript[:6000]}"""

    response = model.generate_content(prompt)
    return response.text

def main():
    if len(sys.argv) < 2:
        url = input("📌 유튜브 URL을 입력하세요: ").strip()
    else:
        url = sys.argv[1]
    
    video_id_match = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11}).*', url)
    if not video_id_match:
        print("❌ 유효한 유튜브 URL이 아닙니다.")
        return
    
    v_id = video_id_match.group(1)
    
    # 제목 가져오기
    print("📋 영상 정보 가져오는 중...")
    try:
        import yt_dlp
        with yt_dlp.YoutubeDL({'quiet': True}) as ydl:
            info = ydl.extract_info(url, download=False)
            title = info.get('title', '제목 없음')
    except:
        title = f"video_{v_id}"
    
    transcript = get_transcript(v_id)
    if not transcript:
        return
    
    md_content = process_ai(title, transcript, v_id)
    
    safe_title = re.sub(r'[<>:"/\\|?*]', '', title)[:80]
    file_path = KNOWLEDGE_DIR / f"{safe_title}.md"
    file_path.write_text(md_content, encoding='utf-8')
    
    print(f"\n✨ 완료! 파일이 저장되었습니다:")
    print(f"📍 {file_path}")

if __name__ == "__main__":
    main()
