"""
🐕 YouTube Office Watchdog — 서버 감시 & 자동 재시작
서버가 죽으면 자동으로 다시 켜고, 수집도 재시작합니다.
"""
import subprocess
import sys
import time
import requests
import os

SERVER_URL = "http://localhost:8000"
SERVER_DIR = os.path.dirname(os.path.abspath(__file__))
CHECK_INTERVAL = 30  # 30초마다 확인

server_process = None

def start_server():
    global server_process
    print(f"🚀 [{time.strftime('%H:%M:%S')}] YouTube Office 서버 시작 중...")
    server_process = subprocess.Popen(
        [sys.executable, "server.py"],
        cwd=SERVER_DIR,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(5)  # 서버 부팅 대기
    
    # 수집 시작 요청
    try:
        r = requests.post(f"{SERVER_URL}/api/start", timeout=10)
        print(f"✅ [{time.strftime('%H:%M:%S')}] 서버 + 수집 시작 완료! (PID: {server_process.pid})")
    except:
        print(f"⚠️ [{time.strftime('%H:%M:%S')}] 서버 시작했지만 수집 API 호출 실패, 재시도...")

def is_server_alive():
    try:
        r = requests.get(f"{SERVER_URL}/api/stats", timeout=5)
        return r.status_code == 200
    except:
        return False

def main():
    print("=" * 50)
    print("🐕 YouTube Office Watchdog 가동")
    print(f"   감시 대상: {SERVER_URL}")
    print(f"   체크 간격: {CHECK_INTERVAL}초")
    print("=" * 50)
    
    restart_count = 0
    
    while True:
        if not is_server_alive():
            restart_count += 1
            print(f"\n💀 [{time.strftime('%H:%M:%S')}] 서버 다운 감지! (재시작 #{restart_count})")
            
            # 기존 프로세스 정리
            if server_process and server_process.poll() is None:
                server_process.kill()
                server_process.wait()
            
            start_server()
        else:
            # 가끔 상태 출력
            try:
                r = requests.get(f"{SERVER_URL}/api/stats", timeout=5)
                stats = r.json()
                total = stats.get("total_collected", 0)
                running = stats.get("is_running", False)
                if not running:
                    # 서버는 살아있지만 수집이 멈춰있으면 재시작
                    print(f"⚠️ [{time.strftime('%H:%M:%S')}] 수집 중단 감지, 재시작...")
                    requests.post(f"{SERVER_URL}/api/start", timeout=10)
                else:
                    print(f"🟢 [{time.strftime('%H:%M:%S')}] 정상 작동 중 | 총 {total}건 수집됨 | 재시작 {restart_count}회", end="\r")
            except:
                pass
        
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
