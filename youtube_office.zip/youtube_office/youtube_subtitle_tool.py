import sys
import os
import json
import re
import subprocess
from pathlib import Path

def get_subtitles(video_url, output_path=None):
    """
    yt-dlp를 사용하여 비디오의 자막을 최선으로 추출합니다.
    """
    print(f"🔍 자막 추출 시작: {video_url}")
    
    # 1. yt-dlp 옵션 설정 (자막만 추출)
    # --write-subs: 수동 자막
    # --write-auto-subs: 자동 생성 자막
    # --skip-download: 영상 제외
    # --sub-lang: 한국어 우선
    
    video_id_match = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11}).*', video_url)
    video_id = video_id_match.group(1) if video_id_match else "temp_video"
    
    cmd = [
        "python", "-m", "yt_dlp",
        "--write-subs", "--write-auto-subs",
        "--sub-lang", "ko,en.*",
        "--skip-download",
        "--convert-subs", "vtt",
        "-o", f"temp_{video_id}.%(ext)s",
        video_url
    ]
    
    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        
        # 생성된 vtt 파일 찾기
        vtt_files = list(Path('.').glob(f"temp_{video_id}*.vtt"))
        
        if not vtt_files:
            print("❌ 자막 파일을 찾을 수 없습니다.")
            return None
        
        # 가장 적절한 파일 선택 (한국어 우선)
        target_file = None
        for f in vtt_files:
            if '.ko.' in f.name:
                target_file = f
                break
        if not target_file:
            target_file = vtt_files[0]
            
        print(f"✅ 자막 파일 발견: {target_file.name}")
        
        # VTT 정제
        content = target_file.read_text(encoding='utf-8')
        lines = content.split('\n')
        clean_text = []
        for line in lines:
            line = line.strip()
            # 시간코드 및 태그 제거
            if not line or '-->' in line or line.startswith(('WEBVTT', 'Language:', 'Kind:')):
                continue
            cleaned = re.sub(r'<[^>]+>', '', line)
            if cleaned and (not clean_text or clean_text[-1] != cleaned):
                clean_text.append(cleaned)
        
        result = " ".join(clean_text)
        
        # 임시 파일 삭제
        for f in vtt_files:
            f.unlink()
            
        if output_path:
            Path(output_path).write_text(result, encoding='utf-8')
            print(f"💾 결과 저장됨: {output_path}")
            
        return result

    except Exception as e:
        print(f"❗ 오류 발생: {e}")
        return None

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python youtube_subtitle_tool.py <video_url> [output_file]")
    else:
        url = sys.argv[1]
        out = sys.argv[2] if len(sys.argv) > 2 else None
        get_subtitles(url, out)
